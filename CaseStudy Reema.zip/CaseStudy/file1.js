function Redirect(){
    location.href="http://127.0.0.1:5500/LandingPage.html";
}
function change(){
    document.getElementsByClassName("cat1").style.background="white";
}
function changeBgcolor(){
    document.getElementById("allData").style.background="blue";
}
function changecol(){
    document.getElementById("allData").style.background="white";
}

function cardFunc(){
    console.log("hi")
    document.getElementById("cardInfo").style.width="200px";
    document.getElementById("cardInfo").style.fontSize="25px";
    document.getElementById("cardImg").style.display="none";
}
function cardBlur(){
    console.log("hi")
    document.getElementById("cardImg").style.display="block";
    document.getElementById("cardInfo").style.fontSize="15px";
}
function RedirectToFacil(){
    location.href="http://127.0.0.1:5500/Facility.html";
}
